def to_uppercase(text):
    return text.upper()

def to_lowercase(text):
    return text.lower()