from my_package.mathop import add, subtract
from my_package.stringop import to_uppercase, to_lowercase

print("Addition:", add(10, 5))
print("Subtraction:", subtract(10, 5))

print("Uppercase:", to_uppercase("hello"))
print("Lowercase:", to_lowercase("WORLD"))


